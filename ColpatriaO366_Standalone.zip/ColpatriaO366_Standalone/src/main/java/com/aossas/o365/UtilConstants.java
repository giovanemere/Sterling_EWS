package com.aossas.o365;

public class UtilConstants {
	public static final String BODY_CONTENT = "BODY_CONTENT";
	public static final String ATTACHMENT_SIZE = "ATTACHMENT_SIZE";
	public static final String ATTACHMENT_MIME_TYPE = "ATTACHMENT_MIME_TYPE";
	public static final String ATTACHMENT_CONTENT = "ATTACHMENT_CONTENT";
	public static final String ATTACHMENT_NAME = "ATTACHMENT_NAME";
	
}

package com.aossas.o365;

import microsoft.exchange.webservices.data.core.PropertySet;
import microsoft.exchange.webservices.data.core.service.schema.EmailMessageSchema;
import microsoft.exchange.webservices.data.property.complex.FileAttachment;

public class ValidateEmail {
	public static void validateAttachment(FileAttachment fileAttachment, PropertySet properties,
            String emailIdentifier, int attachmentSize){
		
		//EmailMessageSchema.Attachments;
		//TODO
	}
}
